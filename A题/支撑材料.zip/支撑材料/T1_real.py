import sympy as sp
import numpy as np
from scipy.optimize import minimize
from tqdm import tqdm

G = -9.8

def distance_point_to_line_segment(p, a, b):
    """计算点p到线段ab的最短距离"""
    if np.all(a == b): return np.linalg.norm(p - a)
    ap, ab = p - a, b - a
    t = np.dot(ap, ab) / np.dot(ab, ab)
    if t < 0.0: return np.linalg.norm(p - a)
    if t > 1.0: return np.linalg.norm(p - b)
    return np.linalg.norm(p - (a + t * ab))

def cone_surface_equation(vertex:np.ndarray, ball_center:np.ndarray, radius:float):
    """生成圆锥面方程的符号表达式"""
    x, y, z = sp.symbols('x y z')
    pointP = np.array([x,y,z])

    VC = ball_center - vertex
    VP = pointP - vertex
    
    # VP的模方
    VP_sq = np.dot(VP, VP)
    # VC的模方
    VC_sq = np.dot(VC, VC)
    # VC点乘VP
    VCdotVP = np.dot(VC, VP)     
    # 构造圆锥面方程
    equation = VCdotVP**2 - (VC_sq - radius**2)*VP_sq
    
    return sp.simplify(equation)

def find_intersection_curve(cone_eq, plane_eq, output=False):
    """求解圆锥面与平面的交线"""
    x, y, z = sp.symbols('x y z')

    # 从平面方程解出一个变量
    if plane_eq.has(z):
        z_expr = sp.solve(plane_eq, z)[0]
        # 代入圆锥面方程
        projection_eq = cone_eq.subs(z, z_expr)
        projection_eq = sp.simplify(projection_eq)
        if output:
            print("\n交线在xy平面的投影方程:")
            print(projection_eq, "= 0")

        return projection_eq
    
    return None

def min_distance_to_curve(x0, y0, eq, num_initial_points=8, tol=1e-6):
    "用SLSQP计算点到曲线的最短距离"
    x, y = sp.symbols('x y')
    ellipse_func = sp.lambdify((x, y), eq, 'numpy')
    
    def objective(params):
        return (params[0] - x0)**2 + (params[1] - y0)**2
    
    def constraint(params):
        return ellipse_func(params[0], params[1])
    
    cons = {'type': 'eq', 'fun': constraint}
    
    # 求解椭圆中心
    center_sols = sp.solve([eq.diff(x), eq.diff(y)], (x, y))
    if not center_sols:
        raise ValueError("无法求解椭圆中心")
    h, k = center_sols[x], center_sols[y]
    
    initial_points = []
    for i in range(num_initial_points):
        angle = 2 * np.pi * i / num_initial_points  # 覆盖完整圆周
        m = np.tan(angle)
        line_eq = y - k - m * (x - h)
        
        # 求解直线与椭圆的交点
        solutions = sp.solve([line_eq, eq], (x, y))
            
        for s in solutions:
            try:
                # 显式转换为数值并过滤实数解
                x_val = float(s[0].evalf())
                y_val = float(s[1].evalf())
                if np.isreal(x_val) and np.isreal(y_val):
                    initial_points.append([x_val, y_val])
            except (TypeError, ValueError):
                continue  # 跳过无效解
    
    # 优化每个初始点
    min_distance = float('inf')
    for point in initial_points:
        result = minimize(
            objective, point, 
            constraints=cons,
            method='SLSQP',
            tol=tol
        ) 
        
        distance = np.sqrt(result.fun)
        if distance < min_distance:
            min_distance = distance
            
    return min_distance

def target_in_shadow(missile_location:np.ndarray, bomb_location:np.ndarray, target_location:tuple):
    """判断真目标圆柱是否在投影范围内"""

    reason = '无'

    if np.linalg.norm(missile_location - bomb_location) <= 10:
        # 导弹在烟雾范围内
        return True, reason
    else:
        # 计算投影圆锥面方程
        x, y, z = sp.symbols('x y z')
        cone_eq = cone_surface_equation(vertex=missile_location, ball_center=bomb_location, radius=10)

        x0 = target_location[0]
        y0 = target_location[1]

        if missile_location[2] > bomb_location[2] + 10:
            # 导弹位置在烟雾上方，此时圆锥面与水平面交线为椭圆
            for z0 in [0, 10]:
                # 判断圆柱上下底面是否在投影内
                plane_eq = z - z0 # 水平面
                ellipse_eq = find_intersection_curve(cone_eq, plane_eq) # 求解交线
                ellipse_func = sp.lambdify((x, y), ellipse_eq, 'numpy')
                center = sp.solve([ellipse_eq.diff(x),ellipse_eq.diff(y)],(x,y))
                f_center = ellipse_func(center[x], center[y])
                f_x0y0 = ellipse_func(x0, y0)
                
                if f_center * f_x0y0 < 0:
                    # 圆心在椭圆外部
                    reason = f'圆心在椭圆外部,{z0}'
                    return False, reason
                else:
                    # 圆心在椭圆内部，计算圆心到椭圆的最小距离
                    min_d = min_distance_to_curve(x0, y0, ellipse_eq)
                    if min_d < 7:
                        reason = f'圆心在椭圆内部,{z0}'
                        return False, reason
        else:
            # 导弹位置和烟雾重合，此时圆锥面与水平面交线为双曲线，需要考虑双曲线的一支
            # 判断圆柱下底面是否在投影内
            plane_eq = z # 水平面
            ellipse_eq = find_intersection_curve(cone_eq, plane_eq) # 求解交线
            ellipse_func = sp.lambdify((x, y), ellipse_eq, 'numpy')
            center = sp.solve([ellipse_eq.diff(x),ellipse_eq.diff(y)],(x,y))
            f_center = ellipse_func(center[x], center[y])
            f_x0y0 = ellipse_func(x0, y0)

            if f_center * f_x0y0 > 0:
                # 圆心在双曲线内侧
                reason = '圆心在双曲线内侧'
                return False, reason
            else:
                # 圆心在双曲线外侧，计算圆心到双曲线的最小距离
                min_d = min_distance_to_curve(x0, y0, ellipse_eq)
                if min_d < 7:
                    reason = '圆心在双曲线外侧'
                    return False, reason
                
        return True, reason
    
def get_cover_time_real(particle:np.ndarray, missile_flying_time, output=False):
    """
    通过求解圆锥面和水平面交线，计算给定无人机方向、角度、飞行时间和起爆时间时的目标被遮蔽的总时间
    :param particle: 含有参数的粒子，[drone_speed, drone_angle, drone_flying_time, bomb_burst_time]
    :param missile_flying_time: 导弹飞行总时间
    :param output:控制是否输出
    :return: 目标被遮蔽总时间
    """
    drone_speed, drone_angle, drone_flying_time, bomb_burst_time = particle.tolist()
    # 无人机方向、角度、飞行时间、起爆时间
    
    # 若无人机飞行时间+起爆时间>=导弹飞行时间，遮蔽时间为0
    if drone_flying_time + bomb_burst_time >= missile_flying_time:
        return 0
     
    fake_target_location = np.array([0,0,0]) # 假目标位置
    real_target_location_points = [] # 取样的真目标点
    for z0 in [0,10]:
        for i in range(0, 100):
            real_target_location_points.append(np.array([7*np.cos(i/50*np.pi),200+7*np.sin(i/50*np.pi),z0]))
    drone_start_location  = np.array([17800,0,1800]) # 无人机起始位置

    drone_direction = np.array([np.cos(drone_angle),np.sin(drone_angle),0]) # 无人机方向向量

    bomb_start_location = drone_start_location + drone_direction * drone_speed * drone_flying_time # 烟雾弹落下位置
    
    bomb_burst_location_x = bomb_start_location[0] + drone_direction[0] * drone_speed * bomb_burst_time
    bomb_burst_location_y = bomb_start_location[1] + drone_direction[1] * drone_speed * bomb_burst_time
    bomb_burst_location_z = bomb_start_location[2] + G * bomb_burst_time**2 / 2
    bomb_burst_location = np.array([bomb_burst_location_x, bomb_burst_location_y, bomb_burst_location_z]) # 烟雾弹爆炸位置
    
    M1_start_location = np.array([20000,0,2000]) # 导弹起始位置
    M1_speed = 300 # 导弹速度
    M1_direction = (fake_target_location - M1_start_location)/np.linalg.norm(fake_target_location - M1_start_location) # 导弹方向向量

    M1_count_location = M1_start_location + M1_direction * (drone_flying_time + bomb_burst_time) * M1_speed # 烟雾弹爆炸时导弹位置

    if output:
        print(f'烟雾弹抛下位置:{bomb_start_location}')
        print(f'烟雾弹爆炸位置:{bomb_burst_location}')
        print(f'导弹方向:{M1_direction}')
        print(f'烟雾弹爆炸时导弹位置:{M1_count_location}')

    bomb_speed = 3
    bomb_direction = np.array([0,0,-1])
    bomb_location = bomb_burst_location.copy()
    M1_location = M1_count_location.copy()
    cover_time = 0
    dt = 0.1
    cover = False

    # 模拟运动过程
    for t in tqdm(np.arange(0, 20, dt),bar_format='模拟进度: {l_bar}{bar}| [{elapsed}<{remaining}, {rate_fmt}{postfix}]'):

        res = target_in_shadow(M1_location, bomb_location, (0,200))
        if res[0] and not cover:
            cover = True
            start_time = t + dt # 记录开始遮蔽时间
        if not res[0] and cover:
            cover = False
            cover_time += t - start_time # 记录结束遮蔽时间
            # print(res[1])

        # 更新烟雾、导弹位置
        bomb_location += dt * bomb_speed * bomb_direction
        M1_location += dt * M1_speed * M1_direction

        if M1_location[2] < bomb_location[2] - 10 or t >= 20:
            # 导弹位置低于烟雾位置或时间超过爆炸20s后结束计算
            if cover:
                cover_time += t - start_time # 结束时，记录遮蔽时间
            break

    return cover_time

if __name__ == '__main__':

    particle = np.array([120, np.pi, 1.5, 3.6]) # 无人机数据

    M1_start_location = np.array([20000,0,2000])
    M1_speed = 300
    missile_flying_time = np.linalg.norm(M1_start_location)/M1_speed # 导弹飞行时间

    # 精确情况计算
    print('\n计算精确情况:')
    real_cover_time = get_cover_time_real(particle, missile_flying_time, output=True)
    print(f'精确计算的导弹被遮蔽时间为:{real_cover_time:.3f} s')