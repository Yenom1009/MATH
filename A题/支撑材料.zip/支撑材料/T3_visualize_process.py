import numpy as np
import math
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from matplotlib.patches import Circle, PathPatch
import mpl_toolkits.mplot3d.art3d as art3d

# =============================================================================
# PART 1: SETUP AND PHYSICS MODEL (Problem 3 Context)
# =============================================================================

# --- Constants ---
GRAVITY = 9.8
M1_INITIAL_POS = np.array([20000.0, 0.0, 2000.0])
MISSILE_SPEED = 300.0
FAKE_TARGET_POS = np.array([0.0, 0.0, 0.0])
FY1_INITIAL_POS = np.array([17800.0, 0.0, 1800.0])
TRUE_TARGET_BOTTOM_CENTER = np.array([0.0, 200.0, 0.0])
TRUE_TARGET_RADIUS = 7.0
TRUE_TARGET_HEIGHT = 10.0
NUM_TARGET_POINTS_PER_CIRCLE = 100
SMOKE_RADIUS = 10.0
SMOKE_DURATION = 20.0
SMOKE_DESCENT_SPEED = 3.0

# --- Physics & Geometry Functions ---
missile_path_vector = FAKE_TARGET_POS - M1_INITIAL_POS
missile_path_length = np.linalg.norm(missile_path_vector)
missile_unit_vector = missile_path_vector / missile_path_length
MISSILE_VELOCITY_VECTOR = MISSILE_SPEED * missile_unit_vector
TIME_TO_IMPACT = missile_path_length / MISSILE_SPEED

def get_missile_position(t):
    return M1_INITIAL_POS + MISSILE_VELOCITY_VECTOR * t

TARGET_POINTS = np.array([p for z_offset in [0, TRUE_TARGET_HEIGHT] for angle in np.linspace(0, 2 * np.pi, NUM_TARGET_POINTS_PER_CIRCLE, endpoint=False) for p in [np.array([TRUE_TARGET_BOTTOM_CENTER[0] + TRUE_TARGET_RADIUS*math.cos(angle), TRUE_TARGET_BOTTOM_CENTER[1] + TRUE_TARGET_RADIUS*math.sin(angle), TRUE_TARGET_BOTTOM_CENTER[2] + z_offset])]])

def check_segment_sphere_intersection(start, end, center, radius):
    v = end - start; w = center - start; proj_dot = np.dot(w, v); v_len_sq = np.dot(v, v)
    if v_len_sq == 0: return np.sum((center - start)**2) <= radius**2
    t = np.clip(proj_dot / v_len_sq, 0, 1); closest = start + t * v
    return np.sum((center - closest)**2) <= radius**2

# =============================================================================
# PART 2: SIMULATION BASED ON THE PROVIDED OPTIMAL STRATEGY
# =============================================================================

# Optimal strategy derived from the user-provided image
OPTIMAL_STRATEGY = [
    135.21,                       # Drone speed (m/s)
    math.radians(-8.76),          # Drone direction (converted to radians)
    20.48,                        # First drop time (s)
    22.28 - 20.48,                # Interval to 2nd drop (s)
    24.08 - 22.28,                # Interval to 3rd drop (s)
    16.53,                        # Fuse time for decoy 1 (s)
    16.03,                        # Fuse time for decoy 2 (s)
    15.53                         # Fuse time for decoy 3 (s)
]

def simulate_strategy(strategy):
    """Simulates the entire engagement and returns data for plotting."""
    v_f, theta, t_drop1, dt2, dt3, tf1, tf2, tf3 = strategy
    
    drone_vel = np.array([v_f * math.cos(theta), v_f * math.sin(theta), 0])
    drone_path_end_time = t_drop1 + dt2 + dt3 + 5 # Plot drone path a bit beyond last drop
    drone_path = np.array([FY1_INITIAL_POS, FY1_INITIAL_POS + drone_vel * drone_path_end_time])
    
    drop_times = [t_drop1, t_drop1 + dt2, t_drop1 + dt2 + dt3]
    fuse_times = [tf1, tf2, tf3]
    
    decoys_data = []
    for i in range(3):
        t_drop = drop_times[i]
        t_fuse = fuse_times[i]
        
        drop_pos = FY1_INITIAL_POS + drone_vel * t_drop
        det_time = t_drop + t_fuse
        det_pos = drop_pos + drone_vel * t_fuse + np.array([0, 0, -0.5 * GRAVITY * t_fuse**2])
        
        traj_times = np.linspace(0, t_fuse, 50)
        traj_points = drop_pos + drone_vel * traj_times[:, np.newaxis] + np.array([0, 0, -0.5 * GRAVITY]) * traj_times[:, np.newaxis]**2
        
        decoys_data.append({
            "drop_time": t_drop, "drop_pos": drop_pos, 
            "det_time": det_time, "det_pos": det_pos,
            "trajectory": traj_points
        })

    # Calculate shielding timeline
    time_grid = np.arange(0, TIME_TO_IMPACT, 0.1)
    shielding_status = []
    detonation_events = [(d['det_time'], d['det_pos']) for d in decoys_data]
    
    for t in time_grid:
        missile_pos = get_missile_position(t)
        active_clouds = [p - np.array([0,0,SMOKE_DESCENT_SPEED*(t-t_det)]) for t_det,p in detonation_events if t_det<=t<t_det+SMOKE_DURATION]
        if not active_clouds:
            shielding_status.append(0)
            continue
        
        is_shielded = all(any(check_segment_sphere_intersection(missile_pos, tp, cloud, SMOKE_RADIUS) for cloud in active_clouds) for tp in TARGET_POINTS)
        shielding_status.append(1 if is_shielded else 0)
        
    return {
        "drone_path": drone_path,
        "missile_path": np.array([M1_INITIAL_POS, get_missile_position(TIME_TO_IMPACT-0.1)]),
        "decoys": decoys_data,
        "time_grid": time_grid,
        "shielding_status": np.array(shielding_status),
        "detonation_events": detonation_events
    }

# =============================================================================
# PART 3: VISUALIZATION FUNCTIONS
# =============================================================================

def plot_3d_trajectory(ax, data):
    ax.plot(data["missile_path"][:,0], data["missile_path"][:,1], data["missile_path"][:,2], 'r-', lw=2, label='Missile M1 Path')
    ax.plot(data["drone_path"][:,0], data["drone_path"][:,1], data["drone_path"][:,2], 'c-', lw=2, label='Drone FY1 Path')
    
    ax.scatter(*M1_INITIAL_POS, c='r', marker='x', s=100, label='M1 Start')
    ax.scatter(*FY1_INITIAL_POS, c='c', marker='x', s=100, label='FY1 Start')
    ax.scatter(*TRUE_TARGET_BOTTOM_CENTER, c='g', marker='s', s=100, label='True Target')
    ax.scatter(*FAKE_TARGET_POS, c='gray', marker='o', s=50, label='Fake Target')
    
    for i, decoy in enumerate(data["decoys"]):
        ax.plot(decoy["trajectory"][:,0], decoy["trajectory"][:,1], decoy["trajectory"][:,2], 'y--', lw=1)
        ax.scatter(*decoy["drop_pos"], c='b', marker='v', s=50, label=f'Decoy {i+1} Drop' if i==0 else "")
        ax.scatter(*decoy["det_pos"], c='orange', marker='*', s=150, ec='black', label=f'Decoy {i+1} Detonation' if i==0 else "")

    ax.set_xlabel('X (m)'); ax.set_ylabel('Y (m)'); ax.set_zlabel('Z (m)')
    ax.set_title('3D Trajectory View')
    ax.legend()
    ax.view_init(elev=20, azim=-120)

def plot_timeline(ax, data):
    total_shield_time = np.sum(data["shielding_status"] * 0.1) # 0.1 is the time step
    
    y_labels = ['Decoy 3', 'Decoy 2', 'Decoy 1', 'Shielding Status']
    ax.set_yticks(range(len(y_labels)))
    ax.set_yticklabels(y_labels)

    for i, decoy in enumerate(data["decoys"]):
        det_time = decoy["det_time"]
        ax.barh(2-i, width=SMOKE_DURATION, left=det_time, height=0.5, color='orange', alpha=0.4, label='Decoy Active Period' if i==0 else "")
        ax.plot(decoy["drop_time"], 2-i, 'bv', markersize=8, label='Drop' if i==0 else "")
        ax.plot(det_time, 2-i, 'r*', markersize=10, label='Detonation' if i==0 else "")
    
    shield_periods = np.where(np.diff(np.concatenate(([0], data["shielding_status"], [0]))) == 1)[0]
    unshield_periods = np.where(np.diff(np.concatenate(([0], data["shielding_status"], [0]))) == -1)[0]
    
    for start, end in zip(shield_periods, unshield_periods):
        ax.barh(3, width=(end-start)*0.1, left=start*0.1, height=0.6, color='mediumseagreen', alpha=0.9, edgecolor='black')
        
    ax.set_xlabel('Time (s)')
    ax.set_title(f'Timeline of Events (Total Shielding: {total_shield_time:.2f}s)')
    ax.grid(axis='x', linestyle=':')
    ax.legend(loc='lower right')

def plot_2d_projection(ax, data):
    ax.plot(data["missile_path"][:,0], data["missile_path"][:,1], 'r-', lw=2, label='Missile M1 Path')
    ax.plot(data["drone_path"][:,0], data["drone_path"][:,1], 'c-', lw=2, label='Drone FY1 Path')
    
    ax.scatter(M1_INITIAL_POS[0], M1_INITIAL_POS[1], c='r', marker='x', s=100)
    ax.scatter(FY1_INITIAL_POS[0], FY1_INITIAL_POS[1], c='c', marker='x', s=100)
    target_circle = Circle((TRUE_TARGET_BOTTOM_CENTER[0], TRUE_TARGET_BOTTOM_CENTER[1]), TRUE_TARGET_RADIUS, color='g', label='True Target')
    ax.add_patch(target_circle)
    ax.scatter(FAKE_TARGET_POS[0], FAKE_TARGET_POS[1], c='gray', marker='o', s=50, label='Fake Target')
    
    for i, decoy in enumerate(data["decoys"]):
        ax.scatter(decoy["drop_pos"][0], decoy["drop_pos"][1], c='b', marker='v', s=50, label=f'Decoy {i+1} Drop' if i==0 else "")
        det_circle = Circle((decoy["det_pos"][0], decoy["det_pos"][1]), SMOKE_RADIUS, color='orange', alpha=0.7, label=f'Decoy {i+1} Det. Area' if i==0 else "")
        ax.add_patch(det_circle)

    ax.set_xlabel('X (m)'); ax.set_ylabel('Y (m)')
    ax.set_title('Top-Down Tactical View')
    ax.legend(); ax.grid(True, linestyle=':'); ax.set_aspect('equal')
    ax.set_xlim(0, 20000)

def plot_shielding_snapshot(ax, data, time_t):
    missile_pos = get_missile_position(time_t)
    active_clouds = [p - np.array([0,0,SMOKE_DESCENT_SPEED*(time_t-t_det)]) for t_det,p in data["detonation_events"] if t_det<=time_t<t_det+SMOKE_DURATION]
    
    for cloud_center in active_clouds:
        p = Circle((cloud_center[1], cloud_center[2]), SMOKE_RADIUS, color='dimgray', alpha=0.8)
        ax.add_patch(p)
    
    ax.plot([200-TRUE_TARGET_RADIUS, 200+TRUE_TARGET_RADIUS], [0, 0], 'g-', lw=3, label='True Target (Bottom)')
    ax.plot([200-TRUE_TARGET_RADIUS, 200+TRUE_TARGET_RADIUS], [10, 10], 'g-', lw=3, label='True Target (Top)')
    ax.scatter(missile_pos[1], missile_pos[2], c='r', marker='x', s=150, label='Missile Position', zorder=10)
    
    for tp in TARGET_POINTS[::10]: # Plot every 10th LOS for clarity
        is_blocked = any(check_segment_sphere_intersection(missile_pos, tp, cloud, SMOKE_RADIUS) for cloud in active_clouds)
        color = 'lime' if is_blocked else 'red'
        ax.plot([missile_pos[1], tp[1]], [missile_pos[2], tp[2]], color=color, lw=0.7, alpha=0.9)
        
    ax.set_xlabel('Y (m)'); ax.set_ylabel('Z (m)')
    ax.set_title(f'Shielding Snapshot at t={time_t:.2f}s (Side View)')
    ax.set_aspect('equal')
    ax.grid(True, linestyle=':')
    
# =============================================================================
# PART 4: MAIN EXECUTION
# =============================================================================
if __name__ == '__main__':
    print("Simulating the provided optimal strategy...")
    simulation_data = simulate_strategy(OPTIMAL_STRATEGY)
    
    print("Generating visualization dashboard...")
    fig = plt.figure(figsize=(20, 18))
    fig.suptitle('Visualization Dashboard for the Optimal Strategy (Problem 3)', fontsize=20)
    
    # Create subplots
    ax1 = fig.add_subplot(2, 2, 1, projection='3d')
    ax2 = fig.add_subplot(2, 2, 2)
    ax3 = fig.add_subplot(2, 2, 3)
    ax4 = fig.add_subplot(2, 2, 4)
    
    # Populate subplots
    plot_3d_trajectory(ax1, simulation_data)
    plot_timeline(ax2, simulation_data)
    plot_2d_projection(ax3, simulation_data)
    
    # Find a good time for the snapshot (middle of a shielded period)
    shielded_times = simulation_data["time_grid"][simulation_data["shielding_status"] == 1]
    snapshot_time = shielded_times[len(shielded_times) // 2] if len(shielded_times) > 0 else 0
    plot_shielding_snapshot(ax4, simulation_data, snapshot_time)
    
    plt.tight_layout(rect=[0, 0.03, 1, 0.95])
    plt.savefig("problem3_final_dashboard.png", dpi=150)
    print("Dashboard saved as 'problem3_final_dashboard.png'")
    plt.show()