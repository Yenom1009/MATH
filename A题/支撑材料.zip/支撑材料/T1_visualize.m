function T1_visualize()
    %1 代表问题1，2 代表问题2
    scenario = 1; 

    %定义常量
    FY1_INITIAL = [17800; 0; 1800];
    M1_INITIAL = [20000; 0; 2000];
    MISSILE_TARGET_POINT = [0; 0; 0];
    TARGET_CYLINDER_BASE_CENTER = [0; 200; 0];
    TARGET_CYLINDER_RADIUS = 7;
    TARGET_CYLINDER_HEIGHT = 10;

    num_points_per_face = 100;
    angles = linspace(0, 2*pi, num_points_per_face+1);
    angles(end) = [];
    x_rim = TARGET_CYLINDER_BASE_CENTER(1) + TARGET_CYLINDER_RADIUS * cos(angles);
    y_rim = TARGET_CYLINDER_BASE_CENTER(2) + TARGET_CYLINDER_RADIUS * sin(angles);
    points_bottom = [x_rim; y_rim; zeros(1, num_points_per_face)];
    points_top = [x_rim; y_rim; ones(1, num_points_per_face) * TARGET_CYLINDER_HEIGHT];
    TARGET_POINTS = [points_bottom, points_top]';

    MISSILE_SPEED = 300;
    CLOUD_FALL_SPEED = 3;
    CLOUD_RADIUS = 10;
    CLOUD_EFFECTIVE_DURATION = 20;
    G = 9.8;
    
    missile_flying_time = norm(MISSILE_TARGET_POINT - M1_INITIAL) / MISSILE_SPEED;
    fprintf('导弹到达其目标(0,0,0)所需时间为: %.2f s\n', missile_flying_time);
    
    m1_dir = (MISSILE_TARGET_POINT - M1_INITIAL) / norm(MISSILE_TARGET_POINT - M1_INITIAL);

    %场景选择,计算最优参数
    if scenario == 1
        params.v = 120;
        params.theta = pi; %朝向假目标(0,0,0)
        params.t_drop = 1.5;
        params.t_d = 3.6;
        title_text = '问题1策略';
    else
        disp('--- 正在使用粒子群(PSO)寻找问题2最优策略以复现结果 (请稍候)... ---');
        nvars = 4;
        lb = [70, 0, 0, 0];
        ub = [140, 2*pi, missile_flying_time, missile_flying_time]; %角度范围改为0-2pi
        
        options = optimoptions('particleswarm', 'SwarmSize', 100, 'MaxIterations', 100, 'Display', 'iter');
        
        objective_fun = @(x) -calculate_effective_time_matlab(x, missile_flying_time, FY1_INITIAL, M1_INITIAL, m1_dir, TARGET_POINTS, MISSILE_SPEED, CLOUD_RADIUS, G, CLOUD_EFFECTIVE_DURATION, CLOUD_FALL_SPEED);
        
        [best_params_vec, ~] = particleswarm(objective_fun, nvars, lb, ub, options);
        
        params.v = best_params_vec(1);
        params.theta = best_params_vec(2);
        params.t_drop = best_params_vec(3);
        params.t_d = best_params_vec(4);
        title_text = '问题2最优策略';
        
        fprintf('\n--- PSO优化完成 ---\n');
        fprintf('最优参数 [v, theta(deg), t_drop, t_d]: [%.2f, %.2f, %.2f, %.2f]\n', ...
            params.v, rad2deg(params.theta), params.t_drop, params.t_d);
    end

    disp('正在使用最优参数进行模拟...');
    time_step = 0.2;
    time_vec = 0:time_step:(missile_flying_time + 5);
    distance_matrix = zeros(200, length(time_vec));
    
    v_x = params.v * cos(params.theta);
    v_y = params.v * sin(params.theta);
    v_bomb_initial = [v_x; v_y; 0];
    p_drop = FY1_INITIAL + v_bomb_initial * params.t_drop;
    p_detonation = p_drop + v_bomb_initial * params.t_d + 0.5 * [0; 0; -G] * params.t_d^2;
    t_detonation = params.t_drop + params.t_d;

    for i = 1:length(time_vec)
        t = time_vec(i);
        p_m1_t = M1_INITIAL + m1_dir * MISSILE_SPEED * t;
        if t < t_detonation || (t - t_detonation) > CLOUD_EFFECTIVE_DURATION
            distance_matrix(:, i) = nan;
            continue;
        end
        p_cloud_t = p_detonation - [0; 0; CLOUD_FALL_SPEED * (t - t_detonation)];
        for j = 1:200
            p_target = TARGET_POINTS(j, :)';
            distance_matrix(j, i) = distance_point_to_linesegment(p_cloud_t, p_m1_t, p_target);
        end
    end
    
    %计算并验证最终时长
    concealed_counts = sum(distance_matrix <= CLOUD_RADIUS, 1);
    all_points_concealed = concealed_counts == 200;
    total_effective_time = sum(all_points_concealed) * time_step;
    fprintf('根据200点模型及优化参数，计算出的总有效遮蔽时长为: %.4f s\n', total_effective_time);
    disp('计算完成，正在生成图表...');

    %创建可视化窗口
    fig = figure('Name', '有效遮蔽分析图', 'Color', 'w', 'Position', [100, 100, 1000, 800]);
    sgtitle(sprintf('%s 的最终状态分析 (Teff = %.2fs)', title_text, total_effective_time), 'FontSize', 16, 'FontWeight', 'bold');
    
    min_distances = min(distance_matrix, [], 1);
    max_distances = max(distance_matrix, [], 1);
    mean_distances = mean(distance_matrix, 1, 'omitnan');
    
    relevant_indices = find(~isnan(min_distances));
    t_plot_start = max(0, time_vec(relevant_indices(1)) - 5);
    t_plot_end = time_vec(relevant_indices(end)) + 5;
    
    %图1: 距离变化曲线
    ax1 = subplot(2, 1, 1, 'Parent', fig);
    hold(ax1, 'on');
    area(ax1, time_vec, min_distances, 'FaceColor', [0.8 1 0.8], 'EdgeColor', 'none', 'DisplayName', '潜在遮蔽期');
    plot(ax1, time_vec, min_distances, 'b-', 'LineWidth', 2, 'DisplayName', '最短距离');
    plot(ax1, time_vec, mean_distances, 'k:', 'LineWidth', 1.5, 'DisplayName', '平均距离');
    yline(ax1, CLOUD_RADIUS, 'r--', 'LineWidth', 2, 'DisplayName', '遮蔽阈值 (10m)');
    title(ax1, '云团中心与200条视线的距离变化');
    xlabel(ax1, '时间 (s)'); ylabel(ax1, '距离 (m)');
    legend(ax1, 'show', 'Location', 'northeast'); grid(ax1, 'on');
    xlim(ax1, [t_plot_start, t_plot_end]);
    
    %图2: 遮蔽数量柱状图
    ax2 = subplot(2, 1, 2, 'Parent', fig);
    hold(ax2, 'on');
    bar(ax2, time_vec, concealed_counts, 'FaceColor', '#4DBEEE', 'BarWidth', 1, 'DisplayName', '被遮蔽视线数');
    full_concealment_times = time_vec(concealed_counts == 200);
    if ~isempty(full_concealment_times)
        bar(ax2, full_concealment_times, concealed_counts(concealed_counts == 200), 'FaceColor', 'g', 'BarWidth', 1, 'DisplayName', '完全有效遮蔽');
    end
    yline(ax2, 200, 'r--', 'LineWidth', 2, 'DisplayName', '100%遮蔽');
    title(ax2, '被有效遮蔽的视线数量');
    xlabel(ax2, '时间 (s)'); ylabel(ax2, '视线数量 (条)');
    legend(ax2, 'show', 'Location', 'northeast'); grid(ax2, 'on');
    xlim(ax2, [t_plot_start, t_plot_end]); ylim(ax2, [0, 220]);

end


function total_time = calculate_effective_time_matlab(particle, missile_flying_time, FY1_INITIAL, M1_INITIAL, m1_dir, TARGET_POINTS, MISSILE_SPEED, CLOUD_RADIUS, G, CLOUD_EFFECTIVE_DURATION, CLOUD_FALL_SPEED)
    v_p = particle(1); theta_p = particle(2); 
    t_drop_p = particle(3); t_d_p = particle(4);

    if t_drop_p + t_d_p >= missile_flying_time, total_time = 0; return; end
    
    v_x_p = v_p * cos(theta_p); v_y_p = v_p * sin(theta_p);
    v_bomb_p = [v_x_p; v_y_p; 0];
    p_drop_p = FY1_INITIAL + v_bomb_p * t_drop_p;
    p_det_p = p_drop_p + v_bomb_p * t_d_p + 0.5 * [0; 0; -G] * t_d_p^2;
    t_det_p = t_drop_p + t_d_p;

    dt_p = 0.2;
    cover_time = 0;
    for t_p = t_det_p : dt_p : (t_det_p + CLOUD_EFFECTIVE_DURATION)
        p_m1_p = M1_INITIAL + m1_dir * MISSILE_SPEED * t_p;
        p_cloud_p = p_det_p - [0; 0; CLOUD_FALL_SPEED * (t_p - t_det_p)];
        
        all_concealed = true;
        for k = 1:size(TARGET_POINTS, 1)
            if distance_point_to_linesegment(p_cloud_p, p_m1_p, TARGET_POINTS(k,:)') > CLOUD_RADIUS
                all_concealed = false;
                break;
            end
        end
        if all_concealed
            cover_time = cover_time + dt_p;
        end
    end
    total_time = cover_time;
end

function d = distance_point_to_linesegment(p, a, b)
    v = b - a; w = p - a;
    if dot(v,v) < 1e-9, d = norm(p-a); return; end
    t = dot(w,v) / dot(v,v);
    if t < 0, d = norm(p-a);
    elseif t > 1, d = norm(p-b);
    else, d = norm(p - (a + t * v));
    end
end