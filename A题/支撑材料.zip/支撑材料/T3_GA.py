import numpy as np
import random

# 定义常量
FY1_START = np.array([17800, 0, 1800])
M1_START = np.array([20000, 0, 2000])
MISSILE_TARGET_POINT = np.array([0, 0, 0])
TARGET_CYLINDER_BASE_CENTER = np.array([0, 200, 0])
TARGET_CYLINDER_RADIUS = 7.0
TARGET_CYLINDER_HEIGHT = 10.0
MISSILE_SPEED = 300.0
CLOUD_FALL_SPEED = 3.0
CLOUD_RADIUS = 10.0
CLOUD_EFFECTIVE_DURATION = 20.0
G = 9.8

# 计算导弹飞行时间
M1_start_location = np.array([20000,0,2000])
M1_speed = 300
M1_ARRIVAL_TIME = np.linalg.norm(M1_start_location)/M1_speed

# 生成目标圆柱体点集
num_target_points_per_face = 100
angles = np.linspace(0, 2 * np.pi, num_target_points_per_face, endpoint=False)
x_rim = TARGET_CYLINDER_BASE_CENTER[0] + TARGET_CYLINDER_RADIUS * np.cos(angles)
y_rim = TARGET_CYLINDER_BASE_CENTER[1] + TARGET_CYLINDER_RADIUS * np.sin(angles)
points_bottom = np.vstack([x_rim, y_rim, np.full_like(x_rim, 0)]).T
points_top = np.vstack([x_rim, y_rim, np.full_like(x_rim, TARGET_CYLINDER_HEIGHT)]).T
TARGET_POINTS = np.vstack([points_bottom, points_top])

# 运动过程模拟相关函数

def distance_point_to_line_segment(p, a, b):
    """计算点p到线段ab的最短距离"""
    if np.all(a == b): 
        return np.linalg.norm(p - a)
    ap, ab = p - a, b - a
    norm_ab_sq = np.dot(ab, ab)
    if norm_ab_sq == 0: 
        return np.linalg.norm(p - a)
    t = np.dot(ap, ab) / norm_ab_sq
    if t < 0.0: 
        return np.linalg.norm(p - a)
    if t > 1.0: 
        return np.linalg.norm(p - b)
    return np.linalg.norm(p - (a + t * ab))

def get_cover_time(particle, output=False):
    """
    用取样点近似计算目标被遮蔽的总时间
    :param particle: 参数粒子 [drone_speed, drone_angle, drone_flying_time, 
                 bomb_burst_time_1, rest_1, bomb_burst_time_2, rest_2, bomb_burst_time_3]
    :param missile_flying_time: 导弹飞行总时间
    :param output: 是否输出详细信息
    :return: 目标被遮蔽总时间
    """
    # 解析参数
    drone_speed = particle[0]
    drone_angle = particle[1]
    drone_flying_time = particle[2]
    bomb_burst_time_1 = particle[3]
    rest_1 = particle[4]
    bomb_burst_time_2 = particle[5]
    rest_2 = particle[6]
    bomb_burst_time_3 = particle[7]
    
    # 计算烟雾弹爆炸时间
    bomb_detonation_times = [
        drone_flying_time + bomb_burst_time_1,
        drone_flying_time + rest_1 + bomb_burst_time_2,
        drone_flying_time + rest_1 + rest_2 + bomb_burst_time_3
    ]
    
    # 检查是否所有烟雾弹都在导弹到达后爆炸
    if all(t >= M1_ARRIVAL_TIME for t in bomb_detonation_times):
        return 0

    # 计算导弹方向向量
    missile_direction = (MISSILE_TARGET_POINT - M1_START) / np.linalg.norm(MISSILE_TARGET_POINT - M1_START)
    
    # 计算无人机方向向量
    drone_direction = np.array([np.cos(drone_angle), np.sin(drone_angle), 0])
    
    # 计算烟雾弹投放和爆炸位置
    bomb_data = []
    for i in range(3):
        if i == 0:
            drop_time = drone_flying_time
            burst_time = bomb_burst_time_1
        elif i == 1:
            drop_time = drone_flying_time + rest_1
            burst_time = bomb_burst_time_2
        else:
            drop_time = drone_flying_time + rest_1 + rest_2
            burst_time = bomb_burst_time_3
            
        # 投放位置
        drop_pos = FY1_START + drone_direction * drone_speed * drop_time
        
        # 爆炸位置（考虑重力影响）
        detonation_pos = drop_pos + drone_direction * drone_speed * burst_time + 0.5 * np.array([0, 0, -G]) * burst_time**2
        
        bomb_data.append({
            'bomb_id': i,
            'detonation_time': bomb_detonation_times[i],
            'expiry_time': bomb_detonation_times[i] + CLOUD_EFFECTIVE_DURATION,
            'detonation_pos': detonation_pos,
            'drop_pos': drop_pos
        })
        
        if output:
            print(f"第{i+1}颗烟雾弹投放位置: {drop_pos}")
            print(f"烟雾弹爆炸位置: {detonation_pos}")

    # 时间步长和总遮蔽时间
    delta_t = 0.2
    cover_time = 0
    cover_time_single = [0] * 3
    
    # 模拟导弹飞行过程
    for t in np.arange(0, M1_ARRIVAL_TIME, delta_t):
        missile_pos = M1_START + missile_direction * MISSILE_SPEED * t
        
        # 检查当前活跃的烟雾弹
        active_bombs = [
            bomb for bomb in bomb_data 
            if bomb['detonation_time'] <= t <= bomb['expiry_time']
        ]
        
        if not active_bombs:
            continue
            
        # 检查所有目标点是否被遮蔽
        all_points_covered = True
        for point in TARGET_POINTS:
            point_covered = False
            
            # 检查该点是否被任何活跃烟雾弹遮蔽
            for bomb in active_bombs:
                # 计算烟雾当前位置（考虑下落）
                cloud_center = bomb['detonation_pos'] - np.array([0, 0, CLOUD_FALL_SPEED * (t - bomb['detonation_time'])])
                
                # 计算点到导弹-目标连线的距离
                distance = distance_point_to_line_segment(cloud_center, missile_pos, point)
                
                if distance <= CLOUD_RADIUS:
                    point_covered = True
                    break
                    
            if not point_covered:
                all_points_covered = False
                break
                
        # 如果所有目标点都被遮蔽，增加遮蔽时间
        if all_points_covered:
            cover_time += delta_t
            
        # 计算单颗烟雾弹的遮蔽时间
        for bomb in active_bombs:
            # 计算烟雾当前位置
            cloud_center = bomb['detonation_pos'] - np.array([0, 0, CLOUD_FALL_SPEED * (t - bomb['detonation_time'])])
            all_points_covered_by_single_bomb = True
            
            for point in TARGET_POINTS:
                distance = distance_point_to_line_segment(cloud_center, missile_pos, point)
                if distance > CLOUD_RADIUS:
                    all_points_covered_by_single_bomb = False
            
            if all_points_covered_by_single_bomb:
                cover_time_single[bomb['bomb_id']] += delta_t

    if output:
        for i in range(3):
            print(f"第{i+1}颗烟雾弹遮蔽时间: {cover_time_single[i]:.2f} s")
        print(f"总遮蔽时间: {cover_time:.2f} s")
    
    return cover_time

# 遗传算法相关函数

def initialize_population(pop_size, bounds):
    """初始化种群"""
    population = np.zeros((pop_size, len(bounds)))
    for i in range(pop_size):
        for j in range(len(bounds)):
            population[i, j] = random.uniform(bounds[j][0], bounds[j][1])
    return population

def roulette_wheel_selection(population, fitness_scores):
    """轮盘赌选择"""
    total_fitness = sum(fitness_scores)
    if total_fitness == 0: # 避免除零错误
        return random.choice(population)
    selection_probs = [f / total_fitness for f in fitness_scores]
    return population[np.random.choice(len(population), p=selection_probs)]

def uniform_crossover(parent1, parent2):
    """均匀交叉"""
    child = parent1.copy()
    for i in range(len(parent1)):
        if random.random() < 0.5:
            child[i] = parent2[i]
    return child

def gaussian_mutation(individual, bounds, mutation_prob, mutation_scale=0.1):
    """高斯变异"""
    mutated_individual = individual.copy()
    for i in range(len(individual)):
        if random.random() < mutation_prob:
            range_width = bounds[i][1] - bounds[i][0]
            mutation = np.random.normal(0, range_width * mutation_scale)
            mutated_individual[i] += mutation
            # 确保仍在边界内
            mutated_individual[i] = np.clip(mutated_individual[i], bounds[i][0], bounds[i][1])
    return mutated_individual

def local_search(individual, bounds):
    """对单个精英个体进行局部搜索"""
    best_neighbor = individual.copy()
    best_fitness = get_cover_time(best_neighbor)

    # 在小邻域内随机扰动20次
    for _ in range(20):
        neighbor = best_neighbor.copy()
        for j in range(2, 8): # 微调 t0i 和 dti
            range_width = bounds[j][1] - bounds[j][0]
            perturbation = np.random.normal(0, range_width * 0.02) # 更小的扰动
            neighbor[j] += perturbation
        
        for d in range(len(neighbor)):
            neighbor[d] = np.clip(neighbor[d], bounds[d][0], bounds[d][1])
        
        # 检查约束
        t01, t02, t03 = neighbor[2], neighbor[4], neighbor[6]
        dt3 = neighbor[7]
        if not (t02 >= t01 + 1.0 and t03 >= t02 + 1.0) or (t03 + dt3 + 20) > M1_ARRIVAL_TIME:
            continue

        neighbor_fitness = get_cover_time(neighbor)
        if neighbor_fitness > best_fitness:
            best_fitness = neighbor_fitness
            best_neighbor = neighbor
    
    return best_neighbor, best_fitness

def optimize_with_genetic():
    """遗传算法主函数"""
    # 定义决策变量的边界
    varbound = [
        (0, 2*np.pi),
        (70.0, 140.0),
        (0, M1_ARRIVAL_TIME-2.1), (0, M1_ARRIVAL_TIME),
        (1.0, M1_ARRIVAL_TIME-1.1), (0, M1_ARRIVAL_TIME),
        (2.0, M1_ARRIVAL_TIME), (0, M1_ARRIVAL_TIME)
    ]
    
    # 配置遗传算法参数
    GA_PARAMS = {
        'num_generations': 100,
        'population_size': 200,
        'elit_ratio': 0.1, # 精英比例
        'crossover_prob': 0.6,
        'mutation_prob': 0.4,
    }
    
    # 初始化
    population = initialize_population(GA_PARAMS['population_size'], varbound)
    best_solution_so_far = None
    best_fitness_so_far = -1

    # 迭代进化
    for gen in range(GA_PARAMS['num_generations']):
        
        # 计算适应度
        fitness_scores = np.array([get_cover_time(ind) for ind in population])
        
        # 寻找当前代的精英
        num_elites = int(GA_PARAMS['population_size'] * GA_PARAMS['elit_ratio'])
        elite_indices = np.argsort(fitness_scores)[-num_elites:]
        elites = population[elite_indices]

        # 局部搜索增强
        print(f"第 {gen+1}/{GA_PARAMS['num_generations']} 代, 最佳时长: {np.max(fitness_scores):.4f}s. 正在微调 {num_elites} 个精英...")
        refined_elites = []
        for elite in elites:
            refined_sol, refined_fit = local_search(elite, varbound)
            refined_elites.append(refined_sol)
        
        # 如果局部搜索找到了全局更优解，则更新
        current_gen_best_idx = np.argmax(fitness_scores)
        if fitness_scores[current_gen_best_idx] > best_fitness_so_far:
            best_fitness_so_far = fitness_scores[current_gen_best_idx]
            best_solution_so_far = population[current_gen_best_idx].copy()

        # 生成新一代
        new_population = list(refined_elites) # 精英直接进入下一代
        
        while len(new_population) < GA_PARAMS['population_size']:
            parent1 = roulette_wheel_selection(population, fitness_scores)
            parent2 = roulette_wheel_selection(population, fitness_scores)
            
            child = uniform_crossover(parent1, parent2)
            child = gaussian_mutation(child, varbound, GA_PARAMS['mutation_prob'])
            new_population.append(child)
            
        population = np.array(new_population)

    # 输出最终结果
    print("优化完成: 最终投放方案")
    print(f"最大有效遮蔽时长 (T_eff): {best_fitness_so_far:.4f} 秒")
    print("最优参数组合:")
    
    theta_opt, v_opt, t01, dt1, t02, dt2, t03, dt3 = best_solution_so_far
    bombs_final = [
        {'id': 1, 't_drop': t01, 't_d': dt1},
        {'id': 2, 't_drop': t02, 't_d': dt2},
        {'id': 3, 't_drop': t03, 't_d': dt3}
    ]
    bombs_final.sort(key=lambda p: p['t_drop'])

    print(f"无人机飞行方向: {np.rad2deg(theta_opt):.2f} 度")
    print(f"无人机飞行速度: {v_opt:.2f} m/s")
    
    for bomb in bombs_final:
        print(f"第{bomb['id']}枚烟幕弹")
        print(f"投弹时间 (t_drop): {bomb['t_drop']:.2f} 秒")
        print(f"引爆延迟 (t_d):    {bomb['t_d']:.2f} 秒")
        print(f"引爆时刻:          {bomb['t_drop'] + bomb['t_d']:.2f} 秒")


if __name__ == "__main__":
    
    # 应用遗传算法
    print('\n遗传算法:')
    optimize_with_genetic()