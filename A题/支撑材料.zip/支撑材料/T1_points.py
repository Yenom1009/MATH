import numpy as np

G = -9.8

def distance_point_to_line_segment(p, a, b):
    """计算点p到线段ab的最短距离"""
    if np.all(a == b): return np.linalg.norm(p - a)
    ap, ab = p - a, b - a
    t = np.dot(ap, ab) / np.dot(ab, ab)
    if t < 0.0: return np.linalg.norm(p - a)
    if t > 1.0: return np.linalg.norm(p - b)
    return np.linalg.norm(p - (a + t * ab))

def get_cover_time_points(particle:np.ndarray, missile_flying_time, output=False):
    """
    通过取样真目标上的点，计算给定无人机方向、角度、飞行时间和起爆时间时的目标被遮蔽的总时间
    :param particle: 含有参数的粒子，[drone_speed, drone_angle, drone_flying_time, bomb_burst_time]
    :param missile_flying_time: 导弹飞行总时间
    :param output:控制是否输出
    :return: 目标被遮蔽总时间
    """
    drone_speed, drone_angle, drone_flying_time, bomb_burst_time = particle.tolist()
    # 无人机方向、角度、飞行时间、起爆时间
    
    # 若无人机飞行时间+起爆时间>=导弹飞行时间，遮蔽时间为0
    if drone_flying_time + bomb_burst_time >= missile_flying_time:
        return 0
     
    fake_target_location = np.array([0,0,0]) # 假目标位置
    real_target_location_points = [] # 取样的真目标点
    for z0 in [0,10]:
        for i in range(0, 100):
            real_target_location_points.append(np.array([7*np.cos(i/50*np.pi),200+7*np.sin(i/50*np.pi),z0]))
    drone_start_location  = np.array([17800,0,1800]) # 无人机起始位置

    drone_direction = np.array([np.cos(drone_angle),np.sin(drone_angle),0]) # 无人机方向向量

    bomb_start_location = drone_start_location + drone_direction * drone_speed * drone_flying_time # 烟雾弹落下位置
    
    bomb_burst_location_x = bomb_start_location[0] + drone_direction[0] * drone_speed * bomb_burst_time
    bomb_burst_location_y = bomb_start_location[1] + drone_direction[1] * drone_speed * bomb_burst_time
    bomb_burst_location_z = bomb_start_location[2] + G * bomb_burst_time**2 / 2
    bomb_burst_location = np.array([bomb_burst_location_x, bomb_burst_location_y, bomb_burst_location_z]) # 烟雾弹爆炸位置
    
    M1_start_location = np.array([20000,0,2000]) # 导弹起始位置
    M1_speed = 300 # 导弹速度
    M1_direction = (fake_target_location - M1_start_location)/np.linalg.norm(fake_target_location - M1_start_location) # 导弹方向向量

    M1_count_location = M1_start_location + M1_direction * (drone_flying_time + bomb_burst_time) * M1_speed # 烟雾弹爆炸时导弹位置

    if output:
        print(f'烟雾弹抛下位置:{bomb_start_location}')
        print(f'烟雾弹爆炸位置:{bomb_burst_location}')
        print(f'导弹方向:{M1_direction}')
        print(f'烟雾弹爆炸时导弹位置:{M1_count_location}')

    cover = False
    t = 0
    delta_t = 0.005 # 时间步长
    bomb_speed = 3 # 烟雾下落速度
    bomb_direction = np.array([0,0,-1]) # 烟雾下落方向向量
    bomb_location = bomb_burst_location.copy()
    M1_location = M1_count_location.copy()
    cover_time = 0
    while(1):
        
        bomb_location += delta_t * bomb_speed * bomb_direction
        M1_location += delta_t * M1_speed * M1_direction

        if M1_location[2] < bomb_location[2]- 10 or t >= 20:
            # 导弹位置低于烟雾位置或时间超过爆炸20s后结束计算
            if cover:
                end_time = t
                cover_time += end_time - start_time
            break
        
        all_in = True
        for point in real_target_location_points:
            distance = distance_point_to_line_segment(bomb_location, M1_location, point) # 导弹与真目标连线到烟雾中心距离
            if distance > 10:
                all_in = False
                
        if not cover and all_in:
            cover = True
            start_time = t
        if cover and not all_in:
            cover = False
            end_time = t
            cover_time += end_time - start_time
        t += delta_t
    return cover_time

if __name__ == '__main__':
    # 主程序

    particle = np.array([120, np.pi, 1.5, 3.6]) # 变量取值

    M1_start_location = np.array([20000,0,2000])
    M1_speed = 300
    missile_flying_time = np.linalg.norm(M1_start_location)/M1_speed # 导弹飞行时间

        # 取样点近似情况计算
    print('\n计算近似情况:')
    points_cover_time = get_cover_time_points(particle,missile_flying_time=67,output=True)
    print(f'取样点近似计算的导弹被遮蔽时间为:{points_cover_time:.3f} s')
