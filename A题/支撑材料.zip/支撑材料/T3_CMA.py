import numpy as np
import cma

# 定义常量
FY1_START = np.array([17800, 0, 1800])
M1_START = np.array([20000, 0, 2000])
MISSILE_TARGET_POINT = np.array([0, 0, 0])
TARGET_CYLINDER_BASE_CENTER = np.array([0, 200, 0])
TARGET_CYLINDER_RADIUS = 7.0
TARGET_CYLINDER_HEIGHT = 10.0
MISSILE_SPEED = 300.0
CLOUD_FALL_SPEED = 3.0
CLOUD_RADIUS = 10.0
CLOUD_EFFECTIVE_DURATION = 20.0
G = 9.8

# 计算导弹飞行时间
M1_start_location = np.array([20000,0,2000])
M1_speed = 300
M1_ARRIVAL_TIME = np.linalg.norm(M1_start_location)/M1_speed

# 生成目标圆柱体点集
num_target_points_per_face = 100
angles = np.linspace(0, 2 * np.pi, num_target_points_per_face, endpoint=False)
x_rim = TARGET_CYLINDER_BASE_CENTER[0] + TARGET_CYLINDER_RADIUS * np.cos(angles)
y_rim = TARGET_CYLINDER_BASE_CENTER[1] + TARGET_CYLINDER_RADIUS * np.sin(angles)
points_bottom = np.vstack([x_rim, y_rim, np.full_like(x_rim, 0)]).T
points_top = np.vstack([x_rim, y_rim, np.full_like(x_rim, TARGET_CYLINDER_HEIGHT)]).T
TARGET_POINTS = np.vstack([points_bottom, points_top])

# 运动过程模拟相关函数

def distance_point_to_line_segment(p, a, b):
    """计算点p到线段ab的最短距离"""
    if np.all(a == b): 
        return np.linalg.norm(p - a)
    ap, ab = p - a, b - a
    norm_ab_sq = np.dot(ab, ab)
    if norm_ab_sq == 0: 
        return np.linalg.norm(p - a)
    t = np.dot(ap, ab) / norm_ab_sq
    if t < 0.0: 
        return np.linalg.norm(p - a)
    if t > 1.0: 
        return np.linalg.norm(p - b)
    return np.linalg.norm(p - (a + t * ab))

def get_cover_time(particle, output=False):
    """
    用取样点近似计算目标被遮蔽的总时间
    :param particle: 参数粒子 [drone_speed, drone_angle, drone_flying_time, 
                 bomb_burst_time_1, rest_1, bomb_burst_time_2, rest_2, bomb_burst_time_3]
    :param missile_flying_time: 导弹飞行总时间
    :param output: 是否输出详细信息
    :return: 目标被遮蔽总时间
    """
    # 解析参数
    drone_speed = particle[0]
    drone_angle = particle[1]
    drone_flying_time = particle[2]
    bomb_burst_time_1 = particle[3]
    rest_1 = particle[4]
    bomb_burst_time_2 = particle[5]
    rest_2 = particle[6]
    bomb_burst_time_3 = particle[7]
    
    # 计算烟雾弹爆炸时间
    bomb_detonation_times = [
        drone_flying_time + bomb_burst_time_1,
        drone_flying_time + rest_1 + bomb_burst_time_2,
        drone_flying_time + rest_1 + rest_2 + bomb_burst_time_3
    ]
    
    # 检查是否所有烟雾弹都在导弹到达后爆炸
    if all(t >= M1_ARRIVAL_TIME for t in bomb_detonation_times):
        return 0

    # 计算导弹方向向量
    missile_direction = (MISSILE_TARGET_POINT - M1_START) / np.linalg.norm(MISSILE_TARGET_POINT - M1_START)
    
    # 计算无人机方向向量
    drone_direction = np.array([np.cos(drone_angle), np.sin(drone_angle), 0])
    
    # 计算烟雾弹投放和爆炸位置
    bomb_data = []
    for i in range(3):
        if i == 0:
            drop_time = drone_flying_time
            burst_time = bomb_burst_time_1
        elif i == 1:
            drop_time = drone_flying_time + rest_1
            burst_time = bomb_burst_time_2
        else:
            drop_time = drone_flying_time + rest_1 + rest_2
            burst_time = bomb_burst_time_3
            
        # 投放位置
        drop_pos = FY1_START + drone_direction * drone_speed * drop_time
        
        # 爆炸位置（考虑重力影响）
        detonation_pos = drop_pos + drone_direction * drone_speed * burst_time + 0.5 * np.array([0, 0, -G]) * burst_time**2
        
        bomb_data.append({
            'bomb_id': i,
            'detonation_time': bomb_detonation_times[i],
            'expiry_time': bomb_detonation_times[i] + CLOUD_EFFECTIVE_DURATION,
            'detonation_pos': detonation_pos,
            'drop_pos': drop_pos
        })
        
        if output:
            print(f"第{i+1}颗烟雾弹投放位置: {drop_pos}")
            print(f"烟雾弹爆炸位置: {detonation_pos}")

    # 时间步长和总遮蔽时间
    delta_t = 0.2
    cover_time = 0
    cover_time_single = [0] * 3
    
    # 模拟导弹飞行过程
    for t in np.arange(0, M1_ARRIVAL_TIME, delta_t):
        missile_pos = M1_START + missile_direction * MISSILE_SPEED * t
        
        # 检查当前活跃的烟雾弹
        active_bombs = [
            bomb for bomb in bomb_data 
            if bomb['detonation_time'] <= t <= bomb['expiry_time']
        ]
        
        if not active_bombs:
            continue
            
        # 检查所有目标点是否被遮蔽
        all_points_covered = True
        for point in TARGET_POINTS:
            point_covered = False
            
            # 检查该点是否被任何活跃烟雾弹遮蔽
            for bomb in active_bombs:
                # 计算烟雾当前位置（考虑下落）
                cloud_center = bomb['detonation_pos'] - np.array([0, 0, CLOUD_FALL_SPEED * (t - bomb['detonation_time'])])
                
                # 计算点到导弹-目标连线的距离
                distance = distance_point_to_line_segment(cloud_center, missile_pos, point)
                
                if distance <= CLOUD_RADIUS:
                    point_covered = True
                    break
                    
            if not point_covered:
                all_points_covered = False
                break
                
        # 如果所有目标点都被遮蔽，增加遮蔽时间
        if all_points_covered:
            cover_time += delta_t
            
        # 计算单颗烟雾弹的遮蔽时间
        for bomb in active_bombs:
            # 计算烟雾当前位置
            cloud_center = bomb['detonation_pos'] - np.array([0, 0, CLOUD_FALL_SPEED * (t - bomb['detonation_time'])])
            all_points_covered_by_single_bomb = True
            
            for point in TARGET_POINTS:
                distance = distance_point_to_line_segment(cloud_center, missile_pos, point)
                if distance > CLOUD_RADIUS:
                    all_points_covered_by_single_bomb = False
            
            if all_points_covered_by_single_bomb:
                cover_time_single[bomb['bomb_id']] += delta_t

    if output:
        for i in range(3):
            print(f"第{i+1}颗烟雾弹遮蔽时间: {cover_time_single[i]:.2f} s")
        print(f"总遮蔽时间: {cover_time:.2f} s")
    
    return cover_time

# CMA算法相关函数

def optimize_with_CMA():
    """CMA算法主函数"""
    # 目标函数定义
    def objective_func(x):
        return -get_cover_time(x)
    
    # 变量边界
    bounds = [
        [70, 0, 0, 0, 1, 0, 1, 0],
        [140, np.pi, M1_ARRIVAL_TIME, M1_ARRIVAL_TIME, M1_ARRIVAL_TIME, M1_ARRIVAL_TIME, M1_ARRIVAL_TIME, M1_ARRIVAL_TIME]
    ]
    
    # 初始解
    x0 = [70, 0] + [np.random.uniform(bounds[0][i], bounds[1][i]/15) for i in range(2,8)] # 缩小时间范围增加可行解概率

    es = cma.CMAEvolutionStrategy(
        x0, 
        0.3,  # 初始步长
        {
            'bounds': bounds,
            'popsize': 80,
            'maxiter': 100
        }
    )
    
    # 执行优化
    es.optimize(objective_func)
    
    # 获取结果
    best_position = es.result.xbest
    best_value = -es.result.fbest
    
    return best_position, best_value

if __name__ == "__main__":

    # 应用CMA算法
    print('\nCMA算法:')
    best_pos, best_val = optimize_with_CMA()
    if best_val > 0:
        print(f"最优解: {best_pos}")
        print(f"最大覆盖时间: {best_val:.4f} s")
    else:
        print('未找到结果!')
    