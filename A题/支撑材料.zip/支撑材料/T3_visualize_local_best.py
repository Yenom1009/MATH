import numpy as np
import math
import matplotlib.pyplot as plt
from tqdm import tqdm

# =============================================================================
# PART 1: SETUP AND PHYSICS MODEL (FROM PREVIOUS PROBLEM)
# =============================================================================

# --- Constants and Initial Conditions ---
GRAVITY = 9.8
M1_INITIAL_POS = np.array([20000.0, 0.0, 2000.0])
MISSILE_SPEED = 300.0
FAKE_TARGET_POS = np.array([0.0, 0.0, 0.0])
FY1_INITIAL_POS = np.array([17800.0, 0.0, 1800.0])
TRUE_TARGET_BOTTOM_CENTER = np.array([0.0, 200.0, 0.0])
TRUE_TARGET_RADIUS = 7.0
TRUE_TARGET_HEIGHT = 10.0
NUM_TARGET_POINTS_PER_CIRCLE = 50
SMOKE_EFFECTIVE_RADIUS = 10.0
SMOKE_EFFECTIVE_DURATION = 20.0
SMOKE_DESCENT_SPEED = 3.0

# --- Pre-computation and Core Functions ---
missile_path_vector = FAKE_TARGET_POS - M1_INITIAL_POS
missile_path_length = np.linalg.norm(missile_path_vector)
missile_unit_vector = missile_path_vector / missile_path_length
MISSILE_VELOCITY_VECTOR = MISSILE_SPEED * missile_unit_vector
TIME_TO_IMPACT = missile_path_length / MISSILE_SPEED

def get_missile_position(t):
    if t < 0 or t > TIME_TO_IMPACT: return None
    return M1_INITIAL_POS + MISSILE_VELOCITY_VECTOR * t

TARGET_POINTS = []
angles = np.linspace(0, 2 * np.pi, NUM_TARGET_POINTS_PER_CIRCLE, endpoint=False)
for z_offset in [0, TRUE_TARGET_HEIGHT]:
    for angle in angles:
        TARGET_POINTS.append(np.array([
            TRUE_TARGET_BOTTOM_CENTER[0] + TRUE_TARGET_RADIUS * math.cos(angle),
            TRUE_TARGET_BOTTOM_CENTER[1] + TRUE_TARGET_RADIUS * math.sin(angle),
            TRUE_TARGET_BOTTOM_CENTER[2] + z_offset
        ]))
TARGET_POINTS = np.array(TARGET_POINTS)

def check_segment_sphere_intersection(seg_start, seg_end, sphere_center, sphere_radius):
    v = seg_end - seg_start
    w = sphere_center - seg_start
    proj_dot = np.dot(w, v)
    v_len_sq = np.dot(v, v)
    if v_len_sq == 0: return np.sum((sphere_center - seg_start)**2) <= sphere_radius**2
    t = np.clip(proj_dot / v_len_sq, 0, 1)
    closest_point = seg_start + t * v
    return np.sum((sphere_center - closest_point)**2) <= sphere_radius**2

def calculate_shielding_time(detonation_events, time_step=0.2):
    if not detonation_events: return 0.0
    total_shielded_time = 0.0
    min_t = min(event[0] for event in detonation_events)
    max_t = min(max(event[0] for event in detonation_events) + SMOKE_EFFECTIVE_DURATION, TIME_TO_IMPACT)

    for t in np.arange(min_t, max_t, time_step):
        missile_pos = get_missile_position(t)
        if missile_pos is None: continue
        active_clouds = [
            p_det - np.array([0, 0, SMOKE_DESCENT_SPEED * (t - t_det)])
            for t_det, p_det in detonation_events if t_det <= t < t_det + SMOKE_EFFECTIVE_DURATION
        ]
        if not active_clouds: continue
        is_fully_shielded = all(
            any(check_segment_sphere_intersection(missile_pos, tp, cloud, SMOKE_EFFECTIVE_RADIUS) for cloud in active_clouds)
            for tp in TARGET_POINTS
        )
        if is_fully_shielded: total_shielded_time += time_step
    return total_shielded_time

# --- A fixed strategy to create the 2D slice ---
BASE_STRATEGY = [120.0, np.pi / 6, 10.0, 2.0, 2.0, 15.0, 15.0, 16.0]

def objective_function_2d(params):
    """Fitness function for the 2D slice."""
    t_drop1, t_fuse1 = params
    strategy = BASE_STRATEGY.copy()
    strategy[2] = t_drop1
    strategy[5] = t_fuse1
    
    v_f, theta, t_drop1, dt2, dt3, tf1, tf2, tf3 = strategy
    drone_vel = np.array([v_f * math.cos(theta), v_f * math.sin(theta), 0])
    
    # We simplify by only calculating the effect of the first two decoys for speed
    detonation_events = []
    # Decoy 1
    d1_drop_pos = FY1_INITIAL_POS + drone_vel * t_drop1
    d1_det_time = t_drop1 + tf1
    d1_det_pos = d1_drop_pos + drone_vel * tf1 + np.array([0, 0, -0.5 * GRAVITY * tf1**2])
    if d1_det_pos[2] > SMOKE_EFFECTIVE_RADIUS:
        detonation_events.append((d1_det_time, d1_det_pos))
    # Decoy 2
    t_drop2 = t_drop1 + dt2
    d2_drop_pos = FY1_INITIAL_POS + drone_vel * t_drop2
    d2_det_time = t_drop2 + tf2
    d2_det_pos = d2_drop_pos + drone_vel * tf2 + np.array([0, 0, -0.5 * GRAVITY * tf2**2])
    if d2_det_pos[2] > SMOKE_EFFECTIVE_RADIUS:
         detonation_events.append((d2_det_time, d2_det_pos))

    return calculate_shielding_time(detonation_events)

# =============================================================================
# PART 2: OPTIMIZATION ALGORITHMS
# =============================================================================

def pso_optimizer(bounds, num_particles, max_iter):
    dim = len(bounds)
    w, c1, c2 = 0.5, 1.5, 1.5
    
    # Initialization
    particles = np.random.rand(num_particles, dim)
    for i in range(dim):
        particles[:, i] = particles[:, i] * (bounds[i][1] - bounds[i][0]) + bounds[i][0]
    
    velocities = np.zeros((num_particles, dim))
    pbest = np.copy(particles)
    pbest_fitness = [objective_function_2d(p) for p in pbest]
    
    gbest_idx = np.argmax(pbest_fitness)
    gbest = pbest[gbest_idx]
    gbest_fitness = pbest_fitness[gbest_idx]
    
    history = [np.copy(particles)]
    gbest_history = [np.copy(gbest)]
    
    for _ in range(max_iter):
        r1, r2 = np.random.rand(num_particles, dim), np.random.rand(num_particles, dim)
        velocities = w * velocities + c1 * r1 * (pbest - particles) + c2 * r2 * (gbest - particles)
        particles += velocities
        
        # Clamp particles to bounds
        for i in range(dim):
            particles[:, i] = np.clip(particles[:, i], bounds[i][0], bounds[i][1])
            
        fitness_values = [objective_function_2d(p) for p in particles]
        
        for i in range(num_particles):
            if fitness_values[i] > pbest_fitness[i]:
                pbest[i] = particles[i]
                pbest_fitness[i] = fitness_values[i]
        
        current_best_idx = np.argmax(pbest_fitness)
        if pbest_fitness[current_best_idx] > gbest_fitness:
            gbest = pbest[current_best_idx]
            gbest_fitness = pbest_fitness[current_best_idx]

        history.append(np.copy(particles))
        gbest_history.append(np.copy(gbest))
        
    return gbest, gbest_fitness, history, gbest_history

def de_optimizer(bounds, pop_size, max_gen, F=0.8, CR=0.9):
    dim = len(bounds)
    
    # Initialization
    population = np.random.rand(pop_size, dim)
    for i in range(dim):
        population[:, i] = population[:, i] * (bounds[i][1] - bounds[i][0]) + bounds[i][0]
        
    fitness = np.array([objective_function_2d(ind) for ind in population])
    history = [np.copy(population)]
    best_idx = np.argmax(fitness)
    best_history = [population[best_idx]]
    
    for _ in range(max_gen):
        new_population = np.copy(population)
        for i in range(pop_size):
            idxs = [idx for idx in range(pop_size) if idx != i]
            a, b, c = population[np.random.choice(idxs, 3, replace=False)]
            
            mutant = np.clip(a + F * (b - c), [b[0] for b in bounds], [b[1] for b in bounds])
            
            cross_points = np.random.rand(dim) < CR
            if not np.any(cross_points):
                cross_points[np.random.randint(0, dim)] = True
            
            trial = np.where(cross_points, mutant, population[i])
            
            trial_fitness = objective_function_2d(trial)
            if trial_fitness > fitness[i]:
                new_population[i] = trial
                fitness[i] = trial_fitness
                
        population = new_population
        history.append(np.copy(population))
        best_idx = np.argmax(fitness)
        best_history.append(population[best_idx])
        
    best_idx = np.argmax(fitness)
    return population[best_idx], fitness[best_idx], history, best_history

# =============================================================================
# PART 3: VISUALIZATION
# =============================================================================
print("Step 1: Calculating fitness landscape. This will take a few minutes...")
# Define the 2D slice to visualize
bounds = [(5, 25), (10, 19)] # (t_drop1 range, t_fuse1 range)
resolution = 60 # Higher resolution to show ruggedness
t_drop1_range = np.linspace(bounds[0][0], bounds[0][1], resolution)
t_fuse1_range = np.linspace(bounds[1][0], bounds[1][1], resolution)

X, Y = np.meshgrid(t_drop1_range, t_fuse1_range)
Z = np.zeros(X.shape)

for i in tqdm(range(resolution), desc="Landscape Calculation"):
    for j in range(resolution):
        Z[i, j] = objective_function_2d((X[i, j], Y[i, j]))

print("Step 2: Running PSO optimizer...")
pso_best, pso_fitness, pso_history, pso_gbest_hist = pso_optimizer(bounds, num_particles=20, max_iter=30)
print(f"PSO found best fitness: {pso_fitness:.4f} at {pso_best}")

print("Step 3: Running DE optimizer...")
de_best, de_fitness, de_history, de_best_hist = de_optimizer(bounds, pop_size=20, max_gen=30)
print(f"DE found best fitness: {de_fitness:.4f} at {de_best}")

print("Step 4: Generating plots...")
# --- Create the 4-panel figure ---
fig, axes = plt.subplots(2, 2, figsize=(20, 18))
fig.suptitle('Analysis of a Rugged Fitness Landscape for Problem 3', fontsize=20)
ax1, ax2, ax3, ax4 = axes.flatten()

# Plot 1: 3D Surface Plot
ax1_3d = fig.add_subplot(2, 2, 1, projection='3d')
surf = ax1_3d.plot_surface(X, Y, Z, cmap='inferno', edgecolor='none')
ax1_3d.set_xlabel('t_drop1 (s)')
ax1_3d.set_ylabel('t_fuse1 (s)')
ax1_3d.set_zlabel('Shielding Time (s)')
ax1_3d.set_title('3D Fitness Landscape')
fig.colorbar(surf, ax=ax1_3d, shrink=0.5, aspect=10, pad=0.1)
ax1.set_visible(False)

# Plot 2: 2D Contour Plot
contour = ax2.contourf(X, Y, Z, levels=20, cmap='inferno')
ax2.set_xlabel('t_drop1 (s)')
ax2.set_ylabel('t_fuse1 (s)')
ax2.set_title('2D Contour Map of the Landscape')
fig.colorbar(contour, ax=ax2)

# Plot 3: PSO Search Path
ax3.contourf(X, Y, Z, levels=20, cmap='inferno')
ax3.set_title('PSO Search Path')
ax3.set_xlabel('t_drop1 (s)')
ax3.set_ylabel('t_fuse1 (s)')
pso_hist_arr = np.array(pso_history)
for i in range(pso_hist_arr.shape[1]): # Iterate through particles
    ax3.plot(pso_hist_arr[:, i, 0], pso_hist_arr[:, i, 1], '-', color='white', alpha=0.3, lw=0.5)
# Plot gbest path
pso_gbest_arr = np.array(pso_gbest_hist)
ax3.plot(pso_gbest_arr[:, 0], pso_gbest_arr[:, 1], 'o-', color='cyan', markersize=5, lw=2, label='gbest Path')
ax3.scatter(pso_history[0][:, 0], pso_history[0][:, 1], marker='o', color='lime', s=50, ec='black', label='Start Positions')
ax3.legend()


# Plot 4: DE Search Path
ax4.contourf(X, Y, Z, levels=20, cmap='inferno')
ax4.set_title('DE Search Path')
ax4.set_xlabel('t_drop1 (s)')
ax4.set_ylabel('t_fuse1 (s)')
de_hist_arr = np.array(de_history)
for i in range(de_hist_arr.shape[1]): # Iterate through population members
    ax4.plot(de_hist_arr[:, i, 0], de_hist_arr[:, i, 1], '-', color='white', alpha=0.3, lw=0.5)
# Plot best individual's path
de_best_arr = np.array(de_best_hist)
ax4.plot(de_best_arr[:, 0], de_best_arr[:, 1], 'o-', color='cyan', markersize=5, lw=2, label='Best Individual Path')
ax4.scatter(de_history[0][:, 0], de_history[0][:, 1], marker='o', color='lime', s=50, ec='black', label='Start Positions')
ax4.legend()


plt.tight_layout(rect=[0, 0, 1, 0.96])
plt.savefig("algorithm_search_visualization.png")
plt.show()